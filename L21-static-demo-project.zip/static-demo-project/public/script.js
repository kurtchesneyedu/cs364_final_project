function showMessage() {
    alert("JavaScript is running in the browser!");
}

console.log("Client-side JavaScript executed.");

